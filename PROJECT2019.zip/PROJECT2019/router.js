var express = require('express');
var companiesRouter = require('./companies/routes');
var customersRouter = require('./customers/routes');
var productsRouter = require('./products/routes');
var eventsRouter = require('./events/routes');

const appRouter = express.Router();

appRouter.use(companiesRouter);
appRouter.use(customersRouter);
appRouter.use(productsRouter);
appRouter.use(eventsRouter);

module.exports = appRouter;