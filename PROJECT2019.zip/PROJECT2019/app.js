var express = require('express');
var bodyParser = require('body-parser');
const appRouter = require('./router');
const middleware = require('./middlewares/common')
// require('dotenv/config');

const app = express();

app.use(middleware.logger);

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());


app.get('/self', (req, res) => {
  res.json("Zarko Jovanoski");
});

app.use(appRouter);

app.use(middleware.wrongRoute);
app.use(middleware.errorHandler);

var port = process.env.PORT || 8080;
app.listen(port, () => {
  console.log(`API is listenig on port ${port}!`);
});

var mysql = require('mysql');

var connection = mysql.createConnection({
  host: 'localhost',
  database: 'bms',
  user: 'root',
  password: 'root',
});

connection.connect(function (err) {
  if (err) {
    console.error('Problem with connection: ' + err.stack);
    return;
  }

  console.log('Connected as id ' + connection.threadId);

});



module.exports = connection;