var express = require('express');
const actions = require('./actions');

var routes = express.Router();

routes.get('/companies', actions.getAllCompanies);
routes.get('/companies/:id', actions.getSpecificCompany);
routes.post('/companies', actions.createCompany);
routes.put('/companies/:id', actions.updateCompany);


module.exports = routes;