var express = require('express');
const actions = require('./actions');

var routes = express.Router();


routes.get('/products', actions.getAllProducts);
routes.get('/products/:id', actions.getSpecificProduct);
routes.post('/products', actions.createProduct);
routes.put('/products/:id', actions.updateProduct);


module.exports = routes;