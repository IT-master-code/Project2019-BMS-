const fs = require('fs');
const path = require('path');
const con = require('../database');

getAllProductsQuery = () => {
    const query = 'SELECT * FROM products';
    return new Promise((resolve, reject) => {
        con.query(query, (error, results, fields) => {
            if (error) {
                reject(error);
            } else {
                resolve(results)
            }
        });
    });
};

getAllProducts = async (req, res) => {
    try {
        const users = await getAllProductsQuery();
        res.status(200).send(users);
    } catch (error) {
        res.status(500).send(error.message);
    }
};

getSpecificProductQuery = (userId) => {
    const query = 'SELECT * FROM products WHERE id = ?';
    return new Promise((resolve, reject) => {
        con.query(query, [userId], (error, results, fields) => {
            if (error) {
                reject(error);
            } else {
                resolve(results)
            }
        });
    });
};

getSpecificProduct = async (req, res, next) => {
    const userId = req.params.id;

    if (userId <= 0) {
        var error = new Error("Id can not be less than 1!");
        error.status = 401;
        return next(error);
    }

    try {
        const user = await getSpecificProductQuery(userId);
        res.status(200).send(user[0]);
    } catch (error) {
        res.status(500).send(error.message);
    }
};


createProductQuery = (user) => {
    const query = 'INSERT INTO products(Category, Subcategory, Name) VALUES (?, ?, ?);';
    return new Promise((resolve, reject) => {
        con.query(query, [products.Category, products.Subcategory, products.Name], (error, results, fields) => {
            if (error) {
                reject(error);
            } else {
                resolve(results);
            }
        });
    });
};

createProduct = async (req, res, next) => {
    try {
        const userRequest = req.body;
        const user = await createProductQuery(userRequest);
        res.status(201).send("Product has been created!");
    } catch (error) {
        res.status(500).send(error.message)
    }
};

updateProductQuery = (id, user) => {
    const query = 'UPDATE products SET Category = ?, Subcategory = ?, Name = ? WHERE id = ?';
    return new Promise((resolve, reject) => {
        con.query(query, [products.Category, products.Subcategory, products.Name, id], (error, results, fields) => {
            if (error) {
                reject(error);
            } else {
                console.log(results)
                if (results.affectedRows == 0) {
                    reject("Nema product so takvo id")
                }
                resolve(results);
            }
        });
    });
};

updateProduct = async (req, res) => {
    const userRequest = req.body;
    const userId = req.params.id
    try {
        const user = await updateProductQuery(userId, userRequest);
        res.status(201).send("Product has been updated!");
    } catch (error) {
        res.status(500).send(error)
    }
};

module.exports = {
    getAllProducts,
    getSpecificProduct,
    createProduct,
    updateProduct
}