const fs = require('fs');
const path = require('path');
const con = require('../database');

getAllEventsQuery = () => {
    const query = 'SELECT * FROM events';
    return new Promise((resolve, reject) => {
        con.query(query, (error, results, fields) => {
            if (error) {
                reject(error);
            } else {
                resolve(results)
            }
        });
    });
};

getAllEvents = async (req, res) => {
    try {
        const users = await getAllEventsQuery();
        res.status(200).send(users);
    } catch (error) {
        res.status(500).send(error.message);
    }
};

getSpecificEventQuery = (userId) => {
    const query = 'SELECT * FROM events WHERE id = ?';
    return new Promise((resolve, reject) => {
        con.query(query, [userId], (error, results, fields) => {
            if (error) {
                reject(error);
            } else {
                resolve(results)
            }
        });
    });
};

getSpecificEvent = async (req, res, next) => {
    const userId = req.params.id;

    if (userId <= 0) {
        var error = new Error("Id can not be less than 1!");
        error.status = 401;
        return next(error);
    }

    try {
        const user = await getSpecificEventQuery(userId);
        res.status(200).send(user[0]);
    } catch (error) {
        res.status(500).send(error.message);
    }
};


createEventQuery = (user) => {
    const query = 'INSERT INTO events(Name, Date and time, Location, Description) VALUES (?, ?, ?, ?);';
    return new Promise((resolve, reject) => {
        con.query(query, [events.Name, events.Date, events.Location, events.Description], (error, results, fields) => {
            if (error) {
                reject(error);
            } else {
                resolve(results);
            }
        });
    });
};

createEvent = async (req, res, next) => {

    try {
        const userRequest = req.body;
        const user = await createEventQuery(userRequest);
        res.status(201).send("Event has been created!");
    } catch (error) {
        res.status(500).send(error.message)
    }

};

updateEventQuery = (id, user) => {
    const query = 'UPDATE events SET Name = ?, Date and time = ?, Location = ?, Description = ? WHERE id = ?';
    return new Promise((resolve, reject) => {
        con.query(query, [events.Name, events.Date, events.Location, events.Description, id], (error, results, fields) => {
            if (error) {
                reject(error);
            } else {
                console.log(results)
                if (results.affectedRows == 0) {
                    reject("Nema Event so takvo id")
                }
                resolve(results);
            }
        });
    });
};

updateEvent = async (req, res) => {
    const userRequest = req.body;
    const userId = req.params.id
    try {
        const user = await updateEventQuery(userId, userRequest);
        res.status(201).send("Event has been updated!");
    } catch (error) {
        res.status(500).send(error)
    }
};

module.exports = {
    getAllEvents,
    getSpecificEvent,
    createEvent,
    updateEvent
}