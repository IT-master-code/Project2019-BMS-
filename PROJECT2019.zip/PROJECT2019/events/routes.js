var express = require('express');
const actions = require('./actions');

var routes = express.Router();



routes.get('/events', actions.getAllEvents);
routes.get('/events/:id', actions.getSpecificEvent);
routes.post('/events', actions.createEvent);
routes.put('/events/:id', actions.updateEvent);

module.exports = routes;