var express = require('express');
const actions = require('./actions');

var routes = express.Router();



routes.get('/customers', actions.getAllCustomers);
routes.get('/customers/:id', actions.getSpecificCustomer);
routes.post('/customers', actions.createCustomer);
routes.put('/customers/:id', actions.updateCustomer);


module.exports = routes;