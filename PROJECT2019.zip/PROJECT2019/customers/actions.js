const fs = require('fs');
const path = require('path');
const { emailValidator } = require('../helper');
const con = require('../database');

getAllCustomersQuery = () => {
    const query = 'SELECT * FROM customers';
    return new Promise((resolve, reject) => {
        con.query(query, (error, results, fields) => {
            if (error) {
                reject(error);
            } else {
                resolve(results)
            }
        });
    });
};

getAllCustomers = async (req, res) => {
    try {
        const users = await getAllCustomersQuery();
        res.status(200).send(users);
    } catch (error) {
        res.status(500).send(error.message);
    }
};

getSpecificCustomerQuery = (userId) => {
    const query = 'SELECT * FROM customers WHERE id = ?';
    return new Promise((resolve, reject) => {
        con.query(query, [userId], (error, results, fields) => {
            if (error) {
                reject(error);
            } else {
                resolve(results)
            }
        });
    });
};

getSpecificCustomer = async (req, res, next) => {
    const userId = req.params.id;

    if (userId <= 0) {
        var error = new Error("Id can not be less than 1!");
        error.status = 401;
        return next(error);
    }

    try {
        const user = await getSpecificCustomerQuery(userId);
        res.status(200).send(user[0]);
    } catch (error) {
        res.status(500).send(error.message);
    }
};


createCustomerQuery = (user) => {
    const query = 'INSERT INTO customers(Name, Surname, , PhoneNo, Email) VALUES (?, ?, ?, ?);';
    return new Promise((resolve, reject) => {
        con.query(query, [customer.Name, customer.Surname, customer.PhoneNo, customer.Email], (error, results, fields) => {
            if (error) {
                reject(error);
            } else {
                resolve(results);
            }
        });
    });
};

createCustomer = async (req, res, next) => {
    let isValid = emailValidator(req.body.Email);
    if (!isValid) {
        var error = new Error("Email is not valid!");
        error.status = 401;
        next(error);
    }
    else {
        try {
            const userRequest = req.body;
            const user = await createCustomerQuery(userRequest);
            res.status(201).send("Customer has been created!");
        } catch (error) {
            res.status(500).send(error.message)
        }
    }
};

updateCustomerQuery = (id, user) => {
    const query = 'UPDATE customers SET Name = ?, Surname = ?, PhoneNo = ?, Email = ? WHERE id = ?';
    return new Promise((resolve, reject) => {
        con.query(query, [customers.Name, customers.Surname, customers.PhoneNo, customers.Email, id], (error, results, fields) => {
            if (error) {
                reject(error);
            } else {
                console.log(results)
                if (results.affectedRows == 0) {
                    reject("Nema Customer so takvo id")
                }
                resolve(results);
            }
        });
    });
};

updateCustomer = async (req, res) => {
    const userRequest = req.body;
    const userId = req.params.id
    try {
        const user = await updateCustomerQuery(userId, userRequest);
        res.status(201).send("Customer has been updated!");
    } catch (error) {
        res.status(500).send(error)
    }
};

module.exports = {
    getAllCustomers,
    getSpecificCustomer,
    createCustomer,
    updateCustomer
}